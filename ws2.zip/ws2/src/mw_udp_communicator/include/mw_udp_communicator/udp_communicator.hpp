#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "geometry_msgs/Vector3.h"
#include "nav_msgs/Odometry.h"
#include <iostream>
#include <stdio.h>
#include <time.h>
#include <string>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include "cassie_out_t.hpp"
#include "cassie_user_in_t.hpp"
#include "udp_proto.hpp"


class UdpCommunicator
{
  public:
    UdpCommunicator(ros::NodeHandle *nh);

  private:
    /*
     * UDP variables
     */
    int sock_;  // Connect user computer to target computer

    // Create packet input/output buffers
    unsigned char recvbuf_[PACKET_HEADER_LEN + CASSIE_OUT_T_PACKED_LEN];
    unsigned char sendbuf_[PACKET_HEADER_LEN + CASSIE_USER_IN_T_PACKED_LEN];

    // Split header and data
    const unsigned char *header_in_;
    const unsigned char *data_in_;
    unsigned char *header_out_;
    unsigned char *data_out_;

    cassie_out_t cassie_out_;  // Create Cassie output structs
    cassie_user_in_t cassie_in_;  // Create Cassie input structs
    packet_header_info_t header_info_ = {0};  // Create header information struct

    // Command types:
    //   0     -> send null values (zeros)
    //   other -> send original values
    int cmd_type_ = 0;

    /*
     * ROS variables
     */
    ros::NodeHandle nh_;
    ros::Subscriber sub_odom_;  // Odometry info from the tracking camera
    ros::Subscriber sub_cmd_;  // Commands from the navigation stack
    ros::Publisher pub_mon_cmd_;  // Monitoring info of velocity commands for debugging
    ros::Publisher pub_mon_tst_;  // Monitoring info of twist for debugging
    ros::Timer tmr_udp_;  // ROS-based timed loop for the UDP transmission
    ros::Timer tmr_mon_;  // ROS-based timed loop for value monitoring
    geometry_msgs::Twist cmd_mon_;  // Command velocity monitoring
    geometry_msgs::Twist tst_mon_;  // Twist monitoring

    void callbackOdom(const nav_msgs::Odometry::ConstPtr& msg);
    // void callbackOdom(const geometry_msgs::Vector3::ConstPtr& msg);
    void callbackCmd(const geometry_msgs::Twist::ConstPtr& msg);
    // void callbackCmd(const geometry_msgs::Vector3::ConstPtr& msg);

    void callbackUdp(const ros::TimerEvent& evt);
    void callbackMon(const ros::TimerEvent& evt);
    void dummyControl(const cassie_out_t *out, cassie_user_in_t *in);
    void initialiseVariables();
    void initialiseSubscribers();
    void initialisePublishers();
    void initialiseTimers();
    void initialiseParams();
};  // End of class UdpCommunicator
